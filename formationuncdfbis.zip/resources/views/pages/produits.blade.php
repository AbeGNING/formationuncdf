@php
    $titrePage = 'Produits'
@endphp

@extends('layouts.principal')

@section('contenu')
    <h1>Prodits</h1>
    bienvenue dans mon site en construction


@stop