@php
    $titrePage = 'Services'
@endphp

@extends('layouts.principal')

@section('contenu')
    <h1>Services</h1>
    bienvenue dans mon site en construction


@stop