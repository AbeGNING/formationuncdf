@php
    $titrePage = 'Accueil'
@endphp

@extends('layouts.principal')

@section('contenu')
    <h1>Accueil</h1>
    bienvenue dans mon site en construction


@stop