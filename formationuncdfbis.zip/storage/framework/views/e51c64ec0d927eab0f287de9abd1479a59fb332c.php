<?php
    $titrePage = 'Services'
?>



<?php $__env->startSection('contenu'); ?>
    <h1>Services</h1>
    bienvenue dans mon site en construction


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\formationuncdfbis\resources\views/pages/services.blade.php ENDPATH**/ ?>