<?php

use Illuminate\Support\Facades\Route;


Route::get('/', function () {
    return view('welcome');
})->name('accueil');

Route::get('/produits', function () {
    return view('welcome');
})->name('produits');

Route::get('/services', function () {
    return view('welcome');
})->name('services');

Route::get('/contactez-nous', function () {
    return view('welcome');
})->name('contact');
